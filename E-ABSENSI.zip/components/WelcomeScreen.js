function WelcomeScreen({ onEnter }) {
    try {
        React.useEffect(() => {
            const timer = setTimeout(() => {
                onEnter();
            }, 3000);
            return () => clearTimeout(timer);
        }, []);

        return (
            <div data-name="welcome-screen" data-file="components/WelcomeScreen.js" 
                 className="min-h-screen smk-bg flex items-center justify-center welcome-screen">
                <div className="text-center text-white p-8">
                    <div className="mb-8">
                        <i className="fas fa-graduation-cap text-8xl mb-4 text-blue-200"></i>
                        <h2 className="text-3xl font-semibold mb-6">APLIKASI E-ABSENSI</h2>
                        <div className="text-xl text-blue-100 space-y-2">
                            <p>SMK Teknologi & Kejuruan</p>
                            <div className="flex flex-wrap justify-center gap-4 mt-4">
                                <span className="bg-blue-600 px-3 py-1 rounded-full text-sm">TKJ</span>
                                <span className="bg-blue-600 px-3 py-1 rounded-full text-sm">RPL</span>
                                <span className="bg-blue-600 px-3 py-1 rounded-full text-sm">AKT</span>
                                <span className="bg-blue-600 px-3 py-1 rounded-full text-sm">TKR</span>
                                <span className="bg-blue-600 px-3 py-1 rounded-full text-sm">TBSM</span>
                            </div>
                        </div>
                    </div>
                    <div className="animate-pulse">
                        <p className="text-lg">Memuat aplikasi...</p>
                        <div className="mt-4">
                            <LoadingSpinner size="lg" />
                        </div>
                    </div>
                </div>
            </div>
        );
    } catch (error) {
        console.error('WelcomeScreen error:', error);
        reportError(error);
        return <div>Loading...</div>;
    }
}

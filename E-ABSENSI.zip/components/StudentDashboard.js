function StudentDashboard({ user, onLogout }) {
    try {
        const [todayAbsensi, setTodayAbsensi] = React.useState([]);
        const [schedules, setSchedules] = React.useState([]);
        const [loading, setLoading] = React.useState(true);
        const [activeTab, setActiveTab] = React.useState('dashboard');

        React.useEffect(() => {
            loadData();
        }, []);

        const loadData = async () => {
            try {
                const today = await AbsensiUtils.getTodayAbsensi(user.objectId);
                const allSchedules = await trickleListObjects('schedule', 100, false);
                const userSchedules = allSchedules.items.filter(s => s.objectData.kelas === user.objectData.kelas);
                
                setTodayAbsensi(today);
                setSchedules(userSchedules);
            } catch (error) {
                console.error('Load data error:', error);
            } finally {
                setLoading(false);
            }
        };

        const handleDeleteAccount = async () => {
            if (confirm('Apakah Anda yakin ingin menghapus akun Anda?\n\nPeringatan: Semua data absensi dan izin Anda akan ikut terhapus dan tidak dapat dikembalikan!')) {
                if (confirm('Konfirmasi sekali lagi: Hapus akun saya secara permanen?')) {
                    try {
                        await trickleDeleteObject('user', user.objectId);
                        alert('Akun Anda telah dihapus');
                        onLogout();
                    } catch (error) {
                        console.error('Delete account error:', error);
                        alert('Gagal menghapus akun');
                    }
                }
            }
        };

        const hasAbsenToday = (type) => {
            return todayAbsensi.some(item => item.objectData.type === type);
        };

        if (loading) {
            return (
                <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100">
                    <LoadingSpinner size="lg" />
                </div>
            );
        }

        return (
            <div data-name="student-dashboard" data-file="components/StudentDashboard.js" 
                 className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
                <div className="bg-gradient-to-r from-blue-600 to-indigo-700 text-white p-6 shadow-lg">
                    <div className="flex justify-between items-center">
                        <div>
                            <h1 className="text-3xl font-bold">Dashboard Siswa</h1>
                            <p className="text-blue-100 text-lg">{user.objectData.nama}</p>
                            <p className="text-blue-200">Kelas: {user.objectData.kelas}</p>
                        </div>
                        <div className="flex space-x-2">
                            <button 
                                onClick={handleDeleteAccount}
                                className="bg-red-500 bg-opacity-80 px-4 py-2 rounded-xl hover:bg-opacity-100 transition-all duration-300 text-sm"
                            >
                                <i className="fas fa-trash mr-1"></i>
                                Hapus Akun
                            </button>
                            <button 
                                onClick={onLogout}
                                className="bg-white bg-opacity-20 px-6 py-3 rounded-xl hover:bg-opacity-30 transition-all duration-300"
                            >
                                <i className="fas fa-sign-out-alt mr-2"></i>
                                Keluar
                            </button>
                        </div>
                    </div>
                </div>

                <div className="p-6">
                    <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-8">
                        {!hasAbsenToday('hadir') && (
                            <button 
                                onClick={() => setActiveTab('absen-hadir')}
                                className="bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white p-4 rounded-2xl text-sm font-medium transition-all shadow-lg"
                            >
                                <i className="fas fa-sign-in-alt mb-2 block text-lg"></i>
                                Absen Hadir
                            </button>
                        )}
                        
                        {!hasAbsenToday('pulang') && (
                            <button 
                                onClick={() => setActiveTab('absen-pulang')}
                                className="bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white p-4 rounded-2xl text-sm font-medium transition-all shadow-lg"
                            >
                                <i className="fas fa-sign-out-alt mb-2 block text-lg"></i>
                                Absen Pulang
                            </button>
                        )}

                        <button 
                            onClick={() => setActiveTab('presensi-teman')}
                            className="bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700 text-white p-4 rounded-2xl text-sm font-medium transition-all shadow-lg"
                        >
                            <i className="fas fa-users mb-2 block text-lg"></i>
                            Presensi Teman
                        </button>

                        <button 
                            onClick={() => setActiveTab('izin')}
                            className="bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white p-4 rounded-2xl text-sm font-medium transition-all shadow-lg"
                        >
                            <i className="fas fa-file-medical mb-2 block text-lg"></i>
                            Ajukan Izin
                        </button>

                        <button 
                            onClick={() => setActiveTab('riwayat')}
                            className="bg-gradient-to-r from-indigo-500 to-indigo-600 hover:from-indigo-600 hover:to-indigo-700 text-white p-4 rounded-2xl text-sm font-medium transition-all shadow-lg"
                        >
                            <i className="fas fa-history mb-2 block text-lg"></i>
                            Riwayat Absensi
                        </button>
                    </div>

                    {activeTab.startsWith('absen-') && (
                        <AbsensiForm 
                            user={user}
                            type={activeTab.split('-')[1]}
                            onSuccess={() => {
                                setActiveTab('dashboard');
                                loadData();
                            }}
                            onCancel={() => setActiveTab('dashboard')}
                        />
                    )}

                    {activeTab === 'presensi-teman' && (
                        <PresensiTeman 
                            currentUser={user}
                            onSuccess={() => setActiveTab('dashboard')}
                            onCancel={() => setActiveTab('dashboard')}
                        />
                    )}

                    {activeTab === 'izin' && (
                        <IzinForm 
                            user={user}
                            onSuccess={() => setActiveTab('dashboard')}
                            onCancel={() => setActiveTab('dashboard')}
                        />
                    )}

                    {activeTab === 'riwayat' && (
                        <AbsensiHistory 
                            user={user}
                            onCancel={() => setActiveTab('dashboard')}
                        />
                    )}

                    {activeTab === 'dashboard' && (
                        <div className="bg-white rounded-2xl card-shadow p-6">
                            <h3 className="text-lg font-semibold mb-4 text-gray-800">
                                <i className="fas fa-calendar-alt mr-2 text-blue-600"></i>
                                Jadwal Pelajaran Hari Ini
                            </h3>
                            <div className="space-y-3">
                                {schedules.map((schedule, index) => (
                                    <div key={index} className="flex justify-between items-center p-4 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl border-l-4 border-blue-500">
                                        <div>
                                            <p className="font-semibold text-blue-800">{schedule.objectData.mataPelajaran}</p>
                                            <p className="text-sm text-blue-600">{schedule.objectData.guru}</p>
                                        </div>
                                        <div className="text-right">
                                            <p className="font-semibold text-blue-800">{schedule.objectData.jam}</p>
                                            <p className="text-sm text-blue-600">{schedule.objectData.hari}</p>
                                        </div>
                                    </div>
                                ))}
                                {schedules.length === 0 && (
                                    <div className="text-center py-8">
                                        <i className="fas fa-calendar-times text-4xl text-gray-400 mb-4"></i>
                                        <p className="text-gray-500">Tidak ada jadwal untuk kelas Anda</p>
                                    </div>
                                )}
                            </div>
                        </div>
                    )}
                </div>
            </div>
        );
    } catch (error) {
        console.error('StudentDashboard error:', error);
        reportError(error);
        return <div>Error loading dashboard</div>;
    }
}

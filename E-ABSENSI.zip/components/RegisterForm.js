function RegisterForm({ onRegister, onSwitchToLogin }) {
    try {
        const [formData, setFormData] = React.useState({
            username: '', nama: '', kelas: '', password: '', confirmPassword: ''
        });
        const [loading, setLoading] = React.useState(false);
        const [error, setError] = React.useState('');

        const handleSubmit = async (e) => {
            e.preventDefault();
            setError('');

            if (formData.password !== formData.confirmPassword) {
                setError('Password tidak cocok');
                return;
            }

            setLoading(true);
            const result = await AuthUtils.register({
                username: formData.username,
                nama: formData.nama,
                kelas: formData.kelas,
                password: formData.password
            });

            if (result.success) {
                onRegister(result.user);
            } else {
                setError(result.message);
            }
            setLoading(false);
        };

        return (
            <div data-name="register-form" data-file="components/RegisterForm.js" 
                 className="min-h-screen gradient-bg flex items-center justify-center p-4">
                <div className="bg-white rounded-2xl card-shadow p-8 w-full max-w-md fade-in">
                    <div className="text-center mb-8">
                        <h1 className="text-3xl font-bold text-gray-800 mb-2">Daftar Akun</h1>
                        <p className="text-gray-600">Buat akun baru untuk absensi</p>
                    </div>

                    {error && (
                        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
                            {error}
                        </div>
                    )}

                    <form onSubmit={handleSubmit} className="space-y-4">
                        <div>
                            <input
                                type="text"
                                value={formData.username}
                                onChange={(e) => setFormData({...formData, username: e.target.value})}
                                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                                placeholder="Username"
                                required
                            />
                        </div>

                        <div>
                            <input
                                type="text"
                                value={formData.nama}
                                onChange={(e) => setFormData({...formData, nama: e.target.value})}
                                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                                placeholder="Nama Lengkap"
                                required
                            />
                        </div>

                        <div>
                            <select
                                value={formData.kelas}
                                onChange={(e) => setFormData({...formData, kelas: e.target.value})}
                                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                                required
                            >
                                <option value="">Pilih Kelas</option>
                                <option value="X-RPL">X-RPL</option>
                                <option value="XI-RPL">XI-RPL</option>
                                <option value="XII-RPL">XII-RPL</option>
                                <option value="X-TKJ">X-TKJ</option>
                                <option value="XI-TKJ">XI-TKJ</option>
                                <option value="XII-TKJ">XII-TKJ</option>
                                <option value="X-AKT">X-AKT</option>
                                <option value="XI-AKT">XI-AKT</option>
                                <option value="XII-AKT">XII-AKT</option>
                                <option value="X-TBSM">X-TBSM</option>
                                <option value="XI-TBSM">XI-TBSM</option>
                                <option value="XII-TBSM">XII-TBSM</option>
                                <option value="X-TKR">X-TKR</option>
                                <option value="XI-TKR">XI-TKR</option>
                                <option value="XII-TKR">XII-TKR</option>
                            </select>
                        </div>

                        <div>
                            <input
                                type="password"
                                value={formData.password}
                                onChange={(e) => setFormData({...formData, password: e.target.value})}
                                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                                placeholder="Password"
                                required
                            />
                        </div>

                        <div>
                            <input
                                type="password"
                                value={formData.confirmPassword}
                                onChange={(e) => setFormData({...formData, confirmPassword: e.target.value})}
                                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                                placeholder="Konfirmasi Password"
                                required
                            />
                        </div>

                        <button
                            type="submit"
                            disabled={loading}
                            className="w-full btn-primary text-white py-3 rounded-lg font-medium disabled:opacity-50"
                        >
                            {loading ? <LoadingSpinner size="sm" /> : 'Daftar'}
                        </button>
                    </form>

                    <div className="text-center mt-6">
                        <p className="text-gray-600">
                            Sudah punya akun?{' '}
                            <button 
                                onClick={onSwitchToLogin}
                                className="text-blue-600 hover:underline font-medium"
                            >
                                Masuk di sini
                            </button>
                        </p>
                    </div>
                </div>
            </div>
        );
    } catch (error) {
        console.error('RegisterForm error:', error);
        reportError(error);
        return <div>Error loading register form</div>;
    }
}

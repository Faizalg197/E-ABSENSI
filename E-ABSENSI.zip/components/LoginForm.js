function LoginForm({ onLogin, onSwitchToRegister }) {
    try {
        const [formData, setFormData] = React.useState({ username: '', password: '' });
        const [loading, setLoading] = React.useState(false);
        const [error, setError] = React.useState('');

        const handleSubmit = async (e) => {
            e.preventDefault();
            setLoading(true);
            setError('');

            const result = await AuthUtils.login(formData.username, formData.password);
            
            if (result.success) {
                onLogin(result.user);
            } else {
                setError(result.message);
            }
            setLoading(false);
        };

        return (
            <div data-name="login-form" data-file="components/LoginForm.js" 
                 className="min-h-screen smk-bg flex items-center justify-center p-4">
                <div className="bg-white rounded-2xl card-shadow p-8 w-full max-w-md fade-in">
                    <div className="text-center mb-8">
                        <i className="fas fa-user-graduate text-4xl text-blue-600 mb-4"></i>
                        <h1 className="text-3xl font-bold text-gray-800 mb-2">E-ABSENSI</h1>
                        <p className="text-gray-600">Masuk ke akun Anda</p>
                    </div>

                    {error && (
                        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
                            {error}
                        </div>
                    )}

                    <form onSubmit={handleSubmit} className="space-y-6">
                        <div>
                            <label className="block text-gray-700 text-sm font-medium mb-2">Username</label>
                            <input
                                type="text"
                                value={formData.username}
                                onChange={(e) => setFormData({...formData, username: e.target.value})}
                                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                                placeholder="Masukkan Username Anda"
                                required
                            />
                        </div>

                        <div>
                            <label className="block text-gray-700 text-sm font-medium mb-2">Password</label>
                            <input
                                type="password"
                                value={formData.password}
                                onChange={(e) => setFormData({...formData, password: e.target.value})}
                                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                                placeholder="Masukkan password"
                                required
                            />
                        </div>

                        <button
                            type="submit"
                            disabled={loading}
                            className="w-full btn-primary text-white py-3 rounded-lg font-medium disabled:opacity-50"
                        >
                            {loading ? <LoadingSpinner size="sm" /> : 'Masuk'}
                        </button>
                    </form>

                    <div className="text-center mt-6">
                        <p className="text-gray-600">
                            Belum punya akun?{' '}
                            <button 
                                onClick={onSwitchToRegister}
                                className="text-blue-600 hover:underline font-medium"
                            >
                                Daftar di sini
                            </button>
                        </p>
                    </div>
                </div>
            </div>
        );
    } catch (error) {
        console.error('LoginForm error:', error);
        reportError(error);
        return <div>Error loading login form</div>;
    }
}

const AbsensiUtils = {
    checkTimeValidation(type) {
        const now = new Date();
        const hour = now.getHours();
        const minute = now.getMinutes();
        const currentTime = hour * 60 + minute;
        
        if (type === 'hadir') {
            const startTime = 5 * 60; // 05:00
            const endTime = 7 * 60 + 30; // 07:30
            const lateTime = 10 * 60; // 10:00
            
            if (currentTime >= startTime && currentTime <= 7 * 60) {
                return 'hadir';
            } else if (currentTime > 7 * 60 && currentTime <= endTime) {
                return 'terlambat';
            } else if (currentTime > endTime && currentTime < lateTime) {
                return 'terlambat';
            } else if (currentTime >= lateTime) {
                return 'alpha';
            }
        } else if (type === 'pulang') {
            const startTime = 16 * 60 + 30; // 16:30
            const endTime = 18 * 60; // 18:00
            return currentTime >= startTime && currentTime <= endTime ? 'hadir' : 'terlambat';
        }
        return 'invalid';
    },

    async submitAbsensi(userId, type, location = null, helperUserId = null, photo = null) {
        try {
            const today = new Date().toISOString().split('T')[0];
            const status = this.checkTimeValidation(type);
            
            if (status === 'invalid') {
                return { success: false, message: 'Waktu absensi tidak valid' };
            }

            const absensiData = {
                userId,
                type,
                date: today,
                timestamp: new Date().toISOString(),
                status,
                location: location || 'Unknown',
                helperUserId: helperUserId || null,
                photo: photo || null
            };

            const absensi = await trickleCreateObject(`absensi:${userId}`, absensiData);
            return { success: true, absensi, status };
        } catch (error) {
            console.error('Absensi error:', error);
            return { success: false, message: 'Gagal menyimpan absensi' };
        }
    },

    async submitIzin(userId, type, reason, date) {
        try {
            const izinData = {
                userId,
                type, // 'sakit' atau 'izin'
                reason,
                date,
                timestamp: new Date().toISOString(),
                status: 'pending'
            };

            const izin = await trickleCreateObject(`izin:${userId}`, izinData);
            return { success: true, izin };
        } catch (error) {
            console.error('Izin error:', error);
            return { success: false, message: 'Gagal mengajukan izin' };
        }
    },

    async getAbsensiHistory(userId, limit = 10) {
        try {
            const absensiList = await trickleListObjects(`absensi:${userId}`, limit, true);
            return absensiList.items;
        } catch (error) {
            console.error('Get absensi history error:', error);
            return [];
        }
    },

    async getTodayAbsensi(userId) {
        try {
            const today = new Date().toISOString().split('T')[0];
            const absensiList = await trickleListObjects(`absensi:${userId}`, 50, true);
            
            return absensiList.items.filter(item => 
                item.objectData.date === today
            );
        } catch (error) {
            console.error('Get today absensi error:', error);
            return [];
        }
    }
};
